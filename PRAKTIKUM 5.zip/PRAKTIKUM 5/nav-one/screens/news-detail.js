import { Image, Text, Heading, Box } from 'native-base';
import { Header } from '../components'

const NewsDetail = ({ route }) => {
  // Get the params
  const params = route.params.item;
  return (
    <>
      <Header title={"News"} withBack="true" />
      <Image source={{ uri: params.image }} alt="Image Berita" size="xl" mt={4} marginLeft={50}/>
      <Box p={4}>
        <Text fontSize="sm" textAlign="center">
          {params.date}
        </Text>
        <Heading mt={2} textAlign="center">
          {params.title}
        </Heading>
        <Text fontSize="md" fontStyle={"inherit"} mt={2}>
          {params.content}
        </Text>
      </Box>
    </>
  );
};

export default NewsDetail;