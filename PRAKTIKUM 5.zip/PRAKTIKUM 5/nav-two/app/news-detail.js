import { Heading, Text, View, Image } from "@gluestack-ui/themed";
import { Header } from "../components";
import { useLocalSearchParams } from "expo-router";

const NewsDetail = () => {
  const params = useLocalSearchParams();
  return (
    <>
      <Header title={"News"} withBack={true} />
      <Image
        source={{ uri: params.image }}
        alt="Image Berita"
        width="100%"
        height={100}
        mt={4}
      />
      <View p={4}>
        <Text fontSize="sm" textAlign="center">
          {params.date}
        </Text>
        <Heading fontSize="xl" mt={2} textAlign="center">
          {params.title}
        </Heading>
        <Text fontSize="md" mt={2}>
          {params.content}
        </Text>
      </View>
    </>
  );
};

export default NewsDetail;
